"use strict";
exports.id = 184;
exports.ids = [184];
exports.modules = {

/***/ 184:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ FinishedRounds)
});

// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: external "react-collapsed"
var external_react_collapsed_ = __webpack_require__(44);
var external_react_collapsed_default = /*#__PURE__*/__webpack_require__.n(external_react_collapsed_);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./src/constant/index.ts
var constant = __webpack_require__(4194);
// EXTERNAL MODULE: ./src/components/HomePage/GetTicket/index.tsx
var GetTicket = __webpack_require__(1723);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/HomePage/FinishedRounds/AllHistory.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); enumerableOnly && (symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; })), keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = null != arguments[i] ? arguments[i] : {}; i % 2 ? ownKeys(Object(source), !0).forEach(function (key) { _defineProperty(target, key, source[key]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









function AllHistory() {
  const {
    getCollapseProps,
    getToggleProps,
    isExpanded
  } = external_react_collapsed_default()();
  const selectedLotteryData = (0,external_react_redux_.useSelector)(state => state.globalState.historyLotteryData);
  const loadingSelectedLotteryData = (0,external_react_redux_.useSelector)(state => state.globalState.loadinghistoryLotteryData);
  const currentHistoryLottery = (0,external_react_redux_.useSelector)(state => state.globalState.currentHistoryLottery);
  const showHegemHistory = currentHistoryLottery === "hegem";
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "p-3",
    children: [/*#__PURE__*/jsx_runtime_.jsx("section", _objectSpread(_objectSpread({}, getCollapseProps()), {}, {
      children: !loadingSelectedLotteryData ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "my-3",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "col-12 align-items-center my-3",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "row",
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "col-3 fnt-s3 fnt-b cl-w ",
              children: "Prize Pot"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "col-7 d-flex justify-content-between align-items-center flex-wrap",
              children: [/*#__PURE__*/jsx_runtime_.jsx(GetTicket/* PrizePotValue */.pV, {
                value: ((selectedLotteryData === null || selectedLotteryData === void 0 ? void 0 : selectedLotteryData.amountCollectedInHera) ?? 0).toFixed(constant/* FIXED_DECIMAL */.x),
                name: "hera"
              }), showHegemHistory && /*#__PURE__*/jsx_runtime_.jsx(GetTicket/* PrizePotValue */.pV, {
                value: ((selectedLotteryData === null || selectedLotteryData === void 0 ? void 0 : selectedLotteryData.amountCollectedInHegem) ?? 0).toFixed(constant/* FIXED_DECIMAL */.x),
                name: "hegem"
              })]
            })]
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "cl-grey fnt-s1 my-3 mb-4",
            children: "Match the winning number in the same order to share prize. Current prizes up for grabs:"
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-12",
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "row",
              children: selectedLotteryData === null || selectedLotteryData === void 0 ? void 0 : selectedLotteryData.coinPerBracket.map(match => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "col-md-3 col-6",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "d-flex flex-column align-items-start",
                  children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "fnt-s2 cl-grey",
                    children: ["MATCH FIRST ", parseInt(match.index) + 1]
                  }), /*#__PURE__*/jsx_runtime_.jsx(GetTicket/* CoinValue */.Ov, {
                    name: "hera",
                    value: (match.hera ?? 0).toFixed(constant/* FIXED_DECIMAL */.x)
                  }), currentHistoryLottery === "hegem" && /*#__PURE__*/jsx_runtime_.jsx(GetTicket/* CoinValue */.Ov, {
                    name: "hegem",
                    value: (match.hegem ?? 0).toFixed(constant/* FIXED_DECIMAL */.x)
                  })]
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "fnt-s1 cl-grey",
                  children: [match.countWinners, " Winning Tickets"]
                })]
              }))
            })
          })]
        })]
      }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-3",
        children: /*#__PURE__*/jsx_runtime_.jsx(external_antd_.Skeleton, {
          active: true
        })
      })
    })), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "w-100 d-flex justify-content-center mt-3 cl-w",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", _objectSpread(_objectSpread({}, getToggleProps()), {}, {
        children: isExpanded ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: ["Hide\xA0", /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/icons/up-arrow.png"
          })]
        }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: ["Detail\xA0", /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "/icons/down-arrow.png"
          })]
        })
      }))
    })]
  });
}
// EXTERNAL MODULE: external "@ant-design/icons"
var icons_ = __webpack_require__(7066);
// EXTERNAL MODULE: ./src/redux/globalState/index.ts
var globalState = __webpack_require__(6058);
// EXTERNAL MODULE: ./src/lib/utils/index.ts
var utils = __webpack_require__(4221);
// EXTERNAL MODULE: external "react-ribbons"
var external_react_ribbons_ = __webpack_require__(7652);
// EXTERNAL MODULE: ./src/config/index.js
var config = __webpack_require__(7930);
;// CONCATENATED MODULE: ./src/components/HomePage/FinishedRounds/TabRoundWinNumber.tsx











const NavRoundWinNumber = () => {
  const dispatch = (0,external_react_redux_.useDispatch)();
  const latestLotteryId = (0,external_react_redux_.useSelector)(state => state.globalState.latestLotteryId);
  const latestHegemLotteryId = (0,external_react_redux_.useSelector)(state => state.globalState.latestHegemLotteryId);
  const selectedLotteryData = (0,external_react_redux_.useSelector)(state => state.globalState.historyLotteryData);
  const currentLotteryId = (0,external_react_redux_.useSelector)(state => state.globalState.currentLotteryId);
  const loadingSelectedLotteryData = (0,external_react_redux_.useSelector)(state => state.globalState.loadinghistoryLotteryData);
  const currentHistoryLottery = (0,external_react_redux_.useSelector)(state => state.globalState.currentHistoryLottery);
  const displayLotteryContractAddress = currentHistoryLottery === "hegem" ? config.LOTTERY_CONTRACT : config.HERA_LOTTERY_CONTRACT;

  const prevLottery = (() => {
    const resLottery = {
      id: currentLotteryId - 1,
      type: currentHistoryLottery
    };
    if (resLottery.id >= 1) return resLottery;

    if (resLottery.type === "hera" && latestHegemLotteryId > 0) {
      return {
        id: latestHegemLotteryId,
        type: "hegem"
      };
    }

    return null;
  })();

  const nextLottery = (() => {
    const resLottery = {
      id: currentLotteryId + 1,
      type: currentHistoryLottery
    };
    if (resLottery.type === "hera" && resLottery.id >= latestLotteryId) return null;

    if (resLottery.type === "hegem" && resLottery.id > latestHegemLotteryId) {
      return {
        id: 1,
        type: "hera"
      };
    }

    return resLottery;
  })();

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "p-2 p-md-4 hrz-b d-flex align-items-baseline align-items-sm-center",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "d-flex flex-column col-7 col-sm-3",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "cl-w fnt-b fnt-s3 d-flex align-items-center",
          children: ["Rounds", /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
            className: "order-badge ml-2",
            children: ["#", currentLotteryId]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "cl-grey fnt-s1 my-1 text-nowrap",
          children: ["Drawn ", selectedLotteryData === null || selectedLotteryData === void 0 ? void 0 : selectedLotteryData.drawnTime]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "col d-none d-md-block px-5",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_antd_.Typography.Text, {
          className: "fnt-s2 cl-w",
          copyable: {
            text: displayLotteryContractAddress,
            tooltips: false,
            icon: Array.from(Array(2)).map(() => /*#__PURE__*/jsx_runtime_.jsx("img", {
              src: "/icons/copy-icon-btn.png",
              className: "ml-1"
            })),
            onCopy: () => external_antd_.message.success("Copied")
          },
          children: ["Contract Address : ", (0,utils/* sliceAddressString */.e)(displayLotteryContractAddress)]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "d-flex align-items-center justity-content-end cl-grey ml-auto",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_antd_.Space, {
          direction: "horizontal",
          size: 15,
          children: [/*#__PURE__*/jsx_runtime_.jsx(icons_.ArrowLeftOutlined, {
            style: {
              color: prevLottery ? "#FFB601" : "#605F60"
            },
            onClick: () => {
              if (prevLottery) {
                dispatch((0,globalState/* setCurrentLotteryId */.Jx)(prevLottery.id));
                dispatch((0,globalState/* setCurrentHistoryLottery */.rK)(prevLottery.type));
              }
            }
          }), /*#__PURE__*/jsx_runtime_.jsx(icons_.ArrowRightOutlined, {
            style: {
              color: nextLottery ? "#FFB601" : "#605F60"
            },
            onClick: () => {
              if (nextLottery) {
                dispatch((0,globalState/* setCurrentLotteryId */.Jx)(nextLottery.id));
                dispatch((0,globalState/* setCurrentHistoryLottery */.rK)(nextLottery.type));
              }
            }
          }), /*#__PURE__*/jsx_runtime_.jsx(icons_.VerticalLeftOutlined, {
            onClick: () => {
              dispatch((0,globalState/* setCurrentLotteryId */.Jx)(latestLotteryId - 1));
              dispatch((0,globalState/* setCurrentHistoryLottery */.rK)("hera"));
            }
          })]
        })
      })]
    }), !loadingSelectedLotteryData ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_ribbons_.RibbonContainer, {
      className: "p-4 hrz-b d-flex flex-wrap justify-content-between align-items-center",
      children: [currentLotteryId === latestLotteryId - 1 && /*#__PURE__*/jsx_runtime_.jsx(external_react_ribbons_.RightCornerRibbon, {
        backgroundColor: "#D91C34",
        color: "#FFFFFF",
        fontFamily: "fontbold",
        children: "Latest"
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "cl-w fnt-b fnt-s3",
        children: "Winning Number"
      }), /*#__PURE__*/jsx_runtime_.jsx(external_antd_.Space, {
        direction: "horizontal",
        size: 15,
        className: "d-flex align-items-center",
        children: selectedLotteryData === null || selectedLotteryData === void 0 ? void 0 : selectedLotteryData.finalNumber.split("").map(number => /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "lottery-number",
          "class-type": number,
          children: number
        }))
      })]
    }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "p-3",
      children: /*#__PURE__*/jsx_runtime_.jsx(external_antd_.Skeleton, {
        active: true
      })
    })]
  });
};

/* harmony default export */ const TabRoundWinNumber = (NavRoundWinNumber);
;// CONCATENATED MODULE: ./src/components/HomePage/FinishedRounds/PersonalHistory.tsx




function PersonalHistory({}) {
  const dispatch = (0,external_react_redux_.useDispatch)();
  const historyPersonalData = (0,external_react_redux_.useSelector)(state => state.globalState.historyPersonalData);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "p-4",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "row",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "col-12 col-sm-3 fnt-s3 fnt-b cl-w ",
        children: "Your Ticket"
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "col d-flex justify-content-between align-items-center flex-wrap",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "d-flex align-items-start flex-column",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "fnt-s1 cl-w",
            children: ["You Have ", /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
              className: "fnt-b cl-yl",
              children: [historyPersonalData === null || historyPersonalData === void 0 ? void 0 : historyPersonalData.numberOfTickets, " Ticket"]
            }), " This Round"]
          }), /*#__PURE__*/jsx_runtime_.jsx("u", {
            className: "fnt-s1 cl-br cursor-pointer",
            onClick: () => dispatch((0,globalState/* setOpenHistoryPersonalTicketInfo */.hi)(true)),
            children: "View your tickets"
          })]
        })
      })]
    })
  });
}
;// CONCATENATED MODULE: ./src/components/HomePage/FinishedRounds/index.tsx






const {
  TabPane
} = external_antd_.Tabs;
function FinishedRounds() {
  const tabRoundWinNumber = /*#__PURE__*/jsx_runtime_.jsx(TabRoundWinNumber, {});

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "finished-rounds my-5 d-flex flex-column align-items-center justify-content-center",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "text-center cl-w fnt-b fnt-s5",
      children: "Finished Rounds"
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_antd_.Tabs, {
      defaultActiveKey: "all_history" // onChange={() => {}}
      ,
      animated: false,
      tabBarGutter: 8,
      className: "w-100",
      children: [/*#__PURE__*/jsx_runtime_.jsx(TabPane, {
        tab: "All History",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "all-history-cont",
          children: [tabRoundWinNumber, /*#__PURE__*/jsx_runtime_.jsx(AllHistory, {})]
        })
      }, "all_history"), /*#__PURE__*/jsx_runtime_.jsx(TabPane, {
        tab: "Your History",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "personal-history-cont",
          children: [tabRoundWinNumber, /*#__PURE__*/jsx_runtime_.jsx(PersonalHistory, {})]
        })
      }, "your_history")]
    })]
  });
}

/***/ })

};
;