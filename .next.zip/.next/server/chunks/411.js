"use strict";
exports.id = 411;
exports.ids = [411];
exports.modules = {

/***/ 411:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ FinishedRounds)
});

// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(725);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
// EXTERNAL MODULE: external "@ant-design/icons"
var icons_ = __webpack_require__(66);
// EXTERNAL MODULE: external "react-ribbons"
var external_react_ribbons_ = __webpack_require__(652);
// EXTERNAL MODULE: external "react-collapsed"
var external_react_collapsed_ = __webpack_require__(44);
var external_react_collapsed_default = /*#__PURE__*/__webpack_require__.n(external_react_collapsed_);
// EXTERNAL MODULE: ./src/components/HomePage/GetTicket/index.tsx
var GetTicket = __webpack_require__(723);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(22);
// EXTERNAL MODULE: ./src/redux/globalState/index.ts
var globalState = __webpack_require__(58);
// EXTERNAL MODULE: ./src/constant/index.ts
var constant = __webpack_require__(194);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/components/HomePage/FinishedRounds/AllHistory.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













function AllHistory({}) {
  const dispatch = (0,external_react_redux_.useDispatch)();
  const {
    getCollapseProps,
    getToggleProps,
    isExpanded
  } = external_react_collapsed_default()();
  const latestLotteryId = (0,external_react_redux_.useSelector)(state => state.globalState.latestLotteryId);
  const selectedLotteryData = (0,external_react_redux_.useSelector)(state => state.globalState.historyLotteryData);
  const currentLotteryId = (0,external_react_redux_.useSelector)(state => state.globalState.currentLotteryId);
  const loadingSelectedLotteryData = (0,external_react_redux_.useSelector)(state => state.globalState.loadinghistoryLotteryData);

  const canPaginate = () => {
    if (currentLotteryId === latestLotteryId) {
      return false;
    } else {
      return true;
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "all-history",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "all-history-cont",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "p-4 hrz-b d-flex justify-content-between align-items-center",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "d-flex flex-column",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "cl-w fnt-b fnt-s3 d-flex align-items-center",
            children: ["Rounds", /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
              className: "order-badge ml-2",
              children: ["#", currentLotteryId - 1]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "cl-grey fnt-s1 my-1",
            children: ["Drawn ", selectedLotteryData === null || selectedLotteryData === void 0 ? void 0 : selectedLotteryData.drawnTime]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "d-flex align-items-center justity-content-end cl-grey",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_antd_.Space, {
            direction: "horizontal",
            size: 15,
            children: [/*#__PURE__*/jsx_runtime_.jsx(icons_.ArrowLeftOutlined, {
              style: {
                color: !(currentLotteryId - 1 === 1) ? "#FFB601" : "#605F60"
              },
              onClick: () => {
                if (!(currentLotteryId - 1 === 1)) {
                  dispatch((0,globalState/* setCurrentLotteryId */.Jx)(currentLotteryId - 1));
                }
              }
            }), /*#__PURE__*/jsx_runtime_.jsx(icons_.ArrowRightOutlined, {
              style: {
                color: !(currentLotteryId === latestLotteryId) ? "#FFB601" : "#605F60"
              },
              onClick: () => {
                if (!(currentLotteryId === latestLotteryId)) {
                  dispatch((0,globalState/* setCurrentLotteryId */.Jx)(currentLotteryId + 1));
                }
              }
            }), /*#__PURE__*/jsx_runtime_.jsx(icons_.VerticalLeftOutlined, {
              onClick: () => {
                dispatch((0,globalState/* setCurrentLotteryId */.Jx)(latestLotteryId));
              }
            })]
          })
        })]
      }), !loadingSelectedLotteryData ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_ribbons_.RibbonContainer, {
        className: "p-4 hrz-b d-flex flex-wrap justify-content-between align-items-center",
        children: [currentLotteryId === latestLotteryId && /*#__PURE__*/jsx_runtime_.jsx(external_react_ribbons_.RightCornerRibbon, {
          backgroundColor: "#D91C34",
          color: "#FFFFFF",
          fontFamily: "fontbold",
          children: "Latest"
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "cl-w fnt-b fnt-s3",
          children: "Winning Number"
        }), /*#__PURE__*/jsx_runtime_.jsx(external_antd_.Space, {
          direction: "horizontal",
          size: 15,
          className: "d-flex align-items-center",
          children: selectedLotteryData === null || selectedLotteryData === void 0 ? void 0 : selectedLotteryData.finalNumber.split("").map(number => /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "lottery-number",
            "class-type": number,
            children: number
          }))
        })]
      }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-3",
        children: /*#__PURE__*/jsx_runtime_.jsx(external_antd_.Skeleton, {
          active: true
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "p-3",
        children: [/*#__PURE__*/jsx_runtime_.jsx("section", _objectSpread(_objectSpread({}, getCollapseProps()), {}, {
          children: !loadingSelectedLotteryData ? /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "my-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "col-12 align-items-center my-3",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "row",
                children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "col-3 fnt-s3 fnt-b cl-w ",
                  children: "Prize Pot"
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                  className: "col-7 d-flex justify-content-between align-items-center flex-wrap",
                  children: [/*#__PURE__*/jsx_runtime_.jsx(GetTicket/* PrizePotValue */.pV, {
                    value: selectedLotteryData === null || selectedLotteryData === void 0 ? void 0 : selectedLotteryData.amountCollectedInHera.toFixed(constant/* FIXED_DECIMAL */.x),
                    name: "hera"
                  }), /*#__PURE__*/jsx_runtime_.jsx(GetTicket/* PrizePotValue */.pV, {
                    value: selectedLotteryData === null || selectedLotteryData === void 0 ? void 0 : selectedLotteryData.amountCollectedInHegem.toFixed(constant/* FIXED_DECIMAL */.x),
                    name: "hegem"
                  })]
                })]
              })
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "cl-grey fnt-s1 my-3 mb-4",
                children: "Match the winning number in the same order to share prize. Current prizes up for grabs:"
              }), /*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "col-12",
                children: /*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "row",
                  children: selectedLotteryData === null || selectedLotteryData === void 0 ? void 0 : selectedLotteryData.coinPerBracket.map(obj => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                    className: "col-md-3 col-6",
                    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: "d-flex flex-column align-items-start",
                      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                        className: "fnt-s2 cl-grey",
                        children: ["MATCH FIRST ", parseInt(obj.index) + 1]
                      }), /*#__PURE__*/jsx_runtime_.jsx(GetTicket/* CoinValue */.Ov, {
                        name: "hera",
                        value: obj.hera.toFixed(constant/* FIXED_DECIMAL */.x)
                      }), /*#__PURE__*/jsx_runtime_.jsx(GetTicket/* CoinValue */.Ov, {
                        name: "hegem",
                        value: obj.hegem.toFixed(constant/* FIXED_DECIMAL */.x)
                      })]
                    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                      className: "fnt-s1 cl-grey",
                      children: [obj.countWinners, " Winning Tickets"]
                    })]
                  }))
                })
              })]
            })]
          }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "p-3",
            children: /*#__PURE__*/jsx_runtime_.jsx(external_antd_.Skeleton, {
              active: true
            })
          })
        })), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "w-100 d-flex justify-content-center mt-3 cl-w",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", _objectSpread(_objectSpread({}, getToggleProps()), {}, {
            children: isExpanded ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
              children: ["Hide\xA0", /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "/icons/up-arrow.png"
              })]
            }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
              children: ["Detail\xA0", /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: "/icons/down-arrow.png"
              })]
            })
          }))
        })]
      })]
    })
  });
}
;// CONCATENATED MODULE: ./src/components/HomePage/FinishedRounds/PersonalHistory.tsx








function PersonalHistory({}) {
  const dispatch = (0,external_react_redux_.useDispatch)();
  const latestLotteryId = (0,external_react_redux_.useSelector)(state => state.globalState.latestLotteryId);
  const selectedLotteryData = (0,external_react_redux_.useSelector)(state => state.globalState.historyLotteryData);
  const currentLotteryId = (0,external_react_redux_.useSelector)(state => state.globalState.currentLotteryId);
  const loadingSelectedLotteryData = (0,external_react_redux_.useSelector)(state => state.globalState.loadinghistoryLotteryData);
  const historyPersonalData = (0,external_react_redux_.useSelector)(state => state.globalState.historyPersonalData);

  const canPaginate = () => {
    return true;
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "personal-history",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "personal-history-cont",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "p-4 hrz-b d-flex justify-content-between align-items-center",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "d-flex flex-column",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "cl-w fnt-b fnt-s3 d-flex align-items-center",
            children: ["Rounds", /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
              className: "order-badge ml-2",
              children: ["#", currentLotteryId - 1]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "cl-grey fnt-s1 my-1",
            children: ["Drawn ", selectedLotteryData === null || selectedLotteryData === void 0 ? void 0 : selectedLotteryData.drawnTime]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "d-flex align-items-center justity-content-end cl-grey",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_antd_.Space, {
            direction: "horizontal",
            size: 15,
            children: [/*#__PURE__*/jsx_runtime_.jsx(icons_.ArrowLeftOutlined, {
              style: {
                color: !(currentLotteryId - 1 === 1) ? "#FFB601" : "#605F60"
              },
              onClick: () => {
                if (!(currentLotteryId - 1 === 1)) {
                  dispatch((0,globalState/* setCurrentLotteryId */.Jx)(currentLotteryId - 1));
                }
              }
            }), /*#__PURE__*/jsx_runtime_.jsx(icons_.ArrowRightOutlined, {
              style: {
                color: !(currentLotteryId === latestLotteryId) ? "#FFB601" : "#605F60"
              },
              onClick: () => {
                if (!(currentLotteryId === latestLotteryId)) {
                  dispatch((0,globalState/* setCurrentLotteryId */.Jx)(currentLotteryId + 1));
                }
              }
            }), /*#__PURE__*/jsx_runtime_.jsx(icons_.VerticalLeftOutlined, {
              onClick: () => {
                dispatch((0,globalState/* setCurrentLotteryId */.Jx)(latestLotteryId));
              }
            })]
          })
        })]
      }), !loadingSelectedLotteryData ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_ribbons_.RibbonContainer, {
        className: "p-4 hrz-b d-flex flex-wrap justify-content-between align-items-center",
        children: [currentLotteryId === latestLotteryId && /*#__PURE__*/jsx_runtime_.jsx(external_react_ribbons_.RightCornerRibbon, {
          backgroundColor: "#D91C34",
          color: "#FFFFFF",
          fontFamily: "fontbold",
          children: "Latest"
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "cl-w fnt-b fnt-s3",
          children: "Winning Number"
        }), /*#__PURE__*/jsx_runtime_.jsx(external_antd_.Space, {
          direction: "horizontal",
          size: 15,
          className: "d-flex align-items-center",
          children: selectedLotteryData === null || selectedLotteryData === void 0 ? void 0 : selectedLotteryData.finalNumber.split("").map(number => /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "lottery-number",
            "class-type": number,
            children: number
          }))
        })]
      }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-3",
        children: /*#__PURE__*/jsx_runtime_.jsx(external_antd_.Skeleton, {
          active: true
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "row",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-3 fnt-s3 fnt-b cl-w ",
            children: "Your Ticket"
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "col-7 d-flex justify-content-between align-items-center flex-wrap",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "d-flex align-items-start flex-column",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "fnt-s1 cl-w",
                children: ["You Have", " ", /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
                  className: "fnt-b cl-yl",
                  children: [historyPersonalData === null || historyPersonalData === void 0 ? void 0 : historyPersonalData.numberOfTickets, " Ticket"]
                }), " ", "This Round"]
              }), /*#__PURE__*/jsx_runtime_.jsx("u", {
                className: "fnt-s1 cl-br cursor-pointer",
                onClick: () => dispatch((0,globalState/* setOpenHistoryPersonalTicketInfo */.hi)(true)),
                children: "View your tickets"
              })]
            })
          })]
        })
      })]
    })
  });
}
;// CONCATENATED MODULE: ./src/components/HomePage/FinishedRounds/index.tsx






function FinishedRounds() {
  const {
    TabPane
  } = external_antd_.Tabs;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "finished-rounds my-5 d-flex flex-column align-items-center justify-content-center",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "text-center cl-w fnt-b fnt-s5",
      children: "Finished Rounds"
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_antd_.Tabs, {
      defaultActiveKey: "allhistory",
      onChange: () => {},
      animated: false,
      tabBarGutter: 8,
      className: "w-100",
      children: [/*#__PURE__*/jsx_runtime_.jsx(TabPane, {
        tab: "All History",
        children: /*#__PURE__*/jsx_runtime_.jsx(AllHistory, {})
      }, "allhistory"), /*#__PURE__*/jsx_runtime_.jsx(TabPane, {
        tab: "Your History",
        children: /*#__PURE__*/jsx_runtime_.jsx(PersonalHistory, {})
      }, "yourhistory")]
    })]
  });
}

/***/ })

};
;